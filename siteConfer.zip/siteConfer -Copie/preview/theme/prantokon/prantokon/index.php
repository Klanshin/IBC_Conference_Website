<!DOCTYPE HTML>
<html lang="zxx">

<!-- Mirrored from colorlib.com/preview/theme/prantokon/prantokon/index-slider.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 29 Jan 2019 09:57:25 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Conference</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" media="all" />
<link rel="stylesheet" type="text/css" href="assets/css/liste.css" media="all" />

<link rel="stylesheet" type="text/css" href="assets/css/slicknav.min.css" media="all" />

<link rel="stylesheet" type="text/css" href="assets/css/icofont.css" media="all" />

<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">

<link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">

<link rel="stylesheet" type="text/css" href="assets/css/switcher-style.css">

<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />

<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="all" />
<link rel="stylesheet" type="text/css" href="assets/css/test2.css" media="all" />

<link rel="icon" type="image/png" href="assets/img/favcion.png" />
<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
</head>


<body data-spy="scroll" data-target=".header" data-offset="50">

<div id="preloader"></div>

<header class="header">
<div class="container">
<div class="row flexbox-center">
<div class="col-lg-2 col-md-3 col-2">
<div class="logo">
<a href="#home"><h1><font color=#1f732e></font></h1></a>
<img src="assets/img/logo2.png" alt="Hand Mockup" />
<img src="assets/img/logo1.jpg" alt="Hand Mockup" />

</div>
</div>
<div class="col-lg-20 col-md-20 col-10">
<div class="responsive-menu"></div>
<div class="mainmenu">
<ul id="primary-menu">
<li><a class="nav-link active" href="#propo"><b>Home</b></a></li>
<li><a class="nav-link" href="#feature"><b>Program</b></a></li>
<li><a class="nav-link" href="#screenshot"><b>Partners</b></a></li>
<li><a class="nav-link" href="#team"><b>Faculty</b></a></li>
<li><a class="nav-link" href="#call"><b>Call For Abstarcts</b></a></li>
<div class="dropdown">
<li><a class="nav-link" href="#blog"><b>Registration</b></a>

 <div class="dropdown-content">
<ul>
<li><a class="nav-link" href="#feature1"><b>Registration fees</b></a></li>               
                    </ul>
					</div>
					</div>
</li>
 </li>
<li><a class="nav-link" href="#contact"><b>Contact</b></a></li>
</ul>
</div>
</div>
</div>
</div>
</header>
<div class="container">
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
	  <li data-target="#myCarousel" data-slide-to="3"></li>
	  <li data-target="#myCarousel" data-slide-to="4"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="assets/img/hero-area.jpg"  style="width:200%;height:550px">
        <div class="carousel-caption">
          <h1>1st International Workshop on Inflammatory Breast Cancer </h1>
         <!-- <p>LA is always so much fun!</p>-->
        </div>
      </div>

      <div class="item">
        <img src="assets/img/eljam.jpg" alt="Chicago" style="width:120%;height:550px">
        <div class="carousel-caption">
          <h2>Inflammatory Breast Cancer International Consortium</h2>
         <!-- <p>Thank you, Chicago!</p>-->
        </div>
      </div>
    
      <div class="item">
        <img src="assets/img/cartaa.png" alt="New York" style="width:100%;height:550px">
        <div class="carousel-caption">
		
          <h3>Association de Formation et de Sensibilisation à l’Oncologie Multidisciplinaire de l’Ariana (AFSOMA)</h3>
         <!-- <p>We love the Big Apple!</p>-->
        </div>
      </div>
     	<div class="item">
        <img src="assets/img/sidi.jpg"  style="width:200%;height:550px">
        <div class="carousel-caption">
          
         <!-- <p>LA is always so much fun!</p>-->
        </div>
      </div>
	  
	  <div class="item">
        <img src="assets/img/tunis.jpg"  style="width:200%;height:550px">
        <div class="carousel-caption">
          
         <!-- <p>LA is always so much fun!</p>-->
        </div>
      </div>
    

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
<!--
<div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
  
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-2" data-slide-to="1"></li>
    <li data-target="#carousel-example-2" data-slide-to="2"></li>
  </ol>
 
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <div class="view">
        <img class="d-block w-100" src="assets/img/slide1.png" 
          alt="First slide">
        <div class="mask rgba-black-light"></div>
      </div>
      <div class="carousel-caption">
        <h3 class="h3-responsive">International Inflammatory Breast Cancer Consortium</h3>
        
      </div>
    </div>
    <div class="carousel-item">
     
      <div class="view">
        <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(6).jpg"
          alt="Second slide">
        <div class="mask rgba-black-strong"></div>
      </div>
      <div class="carousel-caption">
        <h3 class="h3-responsive">1st International Workshop on Inflammatory Breast Cancerk</h3>
       
      </div>
    </div> 1600/707
    <div class="carousel-item">
      
      <div class="view">
        <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(9).jpg"
          alt="Third slide">
        <div class="mask rgba-black-slight"></div>
      </div>
      <div class="carousel-caption">
        <h3 class="h3-responsive">Association de Formation et de Sensibilisation à l’Oncologie Multidisciplinaire de l’Ariana (AFSOMA)</h3>
      
      </div>
    </div>
  </div>

  <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>



<!--<section class="hero-area" id="home">
<div class="hero-area-slider">
<div class="hero-area-single-slide">
<div class="container">
<div class="row">      
<div class="col-lg-7">
<div class="hero-area-content">
<h1> International Inflammatory Breast Cancer Consortium</h1>
</div>
</div>
<div class="col-lg-5">
<div class="hand-mockup text-lg-left text-center">
<!--<ul>
<li><img src="assets/img/eljam.jpg" alt="Hand Mockup" /></li>
<li><img src="assets/img/sidi.jpg" alt="Hand Mockup" /></li></ul>

</div>
</div>
</div>
</div>
</div>
<div class="hero-area-single-slide">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="hero-area-content">
<p><h3>Association de Formation et de Sensibilisation à l’Oncologie Multidisciplinaire de l’Ariana (AFSOMA)</h3><h </p>
</div>
</div>
<div class="col-lg-5">
<div class="hand-mockup text-lg-right text-center">
<!--<img src="assets/img/hand-mockup.jpg" alt="Hand Mockup" />
</div>
<div class="hand-mockup text-lg-right text-center">
<!--<img src="assets/img/sidi.jpg" alt="Hand Mockup" />

</div>
</div>
</div>
</div>
</div>
<div class="hero-area-single-slide">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="hero-area-content">
<h1>1st International Workshop on Inflammatory Breast Cancer</h1>
</div>
</div>
<div class="col-lg-5">
<div class="hand-mockup text-lg-left text-center">
<img src="assets/img/hand-mockup.png" alt="Hand Mockup" />
</div>
</div>
</div>
</div>
</div>
</div>
</section>-->
<section class="blog-area ptb-90" id="propo">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="sec-title">
<h2>Home<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
<br>
<br>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12 col-md-4">
<div class="contact-form">
<center><h3>Tunisia, September 25-26th, 2019</h3></center><br>
<h5>Foreword</h5><br>
<h6>Dear colleagues, </h6><br>
<h6>
The International Inflammatory Breast Cancer Consortium (IBC-IC) will organise the 1st Workshop on Inflammatory Breast Cancer.<br><br> Our primary goal is to spread worldwide knowledge about IBC.<br><br>  We organize educational conferences and workshops that are evidence-based and updated to latest  advancement in IBC management.<br><br> We believe that strong collaboration between health professionals and advocates is essential to raise awareness and face the<br><br> challenges faced by this under-represented group of patients.<br><br>  
It is therefore with great enthusiasm that we invite you to attend the 1st workshop that will take place in Tunis, Tunisia, On <br><br>September 25th-26th, 2019. <br><br>
<!--Toward a better IBC patients care.<br><br><br><br>-->
<i>Pr. Hamouda BOUSSEN & Pr. Massimo CRISTOFANILLI</i>
</h6>
</form>
</div></div>
</div>
</div>
<br><br><br>
<h6><b><center>Toward a better IBC patients care</center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress</b></h6>
<img src="assets/img/icone.png" alt="feature"><p>

</div>



</section>
<section class="feature-area ptb-90" id="feature">
<div class="row flexbox-left">
<div class="col-lg-4">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
<i class="icofont icofont-eye"></i>
</div>
<div class="feature-box-info">
<h4><center>Wednesday 25th, 2019</center></h4><br>
<center><b><h4>Session 1<br> </h4> </b></center><br>
<b>Epidemiological aspects <br>of Inflammatory Breast Cancer<br><br>
<center><h4>Session 2 </h4></center><br>
Molecular biology of <br>Inflammatory Breast Cancer<br><br>

<center><h4>Session 3</h4></center> <br>
Immune landscape of <br>Inflammatory Breast Cancer<br><br>
<h4><center>Session 4</h4></center> <br>
What’s next in Inflammatory Breast Cancer management</b>   
</div>
<div class="feature-box-icon">
</div>
</li>
</ul>
</div>
</div>
<div class="col-lg-4">
<div class="single-feature-box text-center">
<img src="assets/img/feature.png" alt="feature">
<a href="#"><h4><b><i>Click here </i></b></h4></a><p><b>to download the program<br>(In Process)</p>
</div>
</div>
<div class="col-lg-12">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
<i class="icofont icofont-eye"></i>
</div>
<div class="feature-box-info">      
<h4>Thursday September 26th, 2019</h4><br>
<p><center><b> </b></center></p>
<b><h4><center>Session 5</center></h4></b> <br>
<p><center>Current and Perspectives of Inflammatory</center>Breast Cancer </p><br><br>
<b><h4><center>Session 6</center></h4></b> <br>
<p><center>Challenges and social aspects<br> of Inflammatory Breast Cancer</center></p><br><br>
</div>
</li>
</ul>
</div>
</div>
</div>
</div><br><br><br><br><br><br><br><br><br>
<h6><b><center>Toward a better IBC patients care</center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress</b></h6>
<img src="assets/img/icone.png" alt="feature"> 

</div>
</section>
</li>
<section class="screenshots-area ptb-90" id="screenshot">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="sec-title">
<h2>Partners<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
<p>Partners of Conference </p>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12">
<div class="screenshot-wrap">
<!--<div class="single-screenshot">
<img src="assets/img/screenshot/screenshot1.jpg" alt="screenshot" />
</div>-->
<!--<div class="single-screenshot">
<img src="assets/img/screenshot/roche.png" alt="screenshot" />
</div>-->
<!--<div class="single-screenshot">
<img src="assets/img/screenshot/novatris.png" alt="screenshot" />
</div>-->
<div class="single-screenshot">
<img src="assets/img/screenshot/medecin.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/screenshot4.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/fst.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/pasteur.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/stor.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/screen9.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/screenshot/ibc.jpg" alt="screenshot" />
</div>
</div>
<h6><b><center>Toward a better IBC patients care </center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress 
</b></h6>
<img src="assets/img/icone.png" alt="feature"> 

</div>
</div>
</div>
</div>
</div>
</section>
<section class="feature-area ptb-90" id="team">
<div class="container">
<div class="row flexbox-left">
<div class="col-lg-4">
<div class="single-feature-box text-lg-right text-center">
<ul>
<li>
<div class="feature-box-info">
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/author1.jpg" alt="author" />
</div>
<!--<h5>Hamouda BOUSSEN</h5>-->
Pr. Hamouda BOUSSEN, MD<br>
Medical Oncology<br>
Oncology Center, Abderrahmen Mami Hospital, Ariana, Tunisia<br>
AFSOMA President<br>

<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
</div>
</div>
<div class="feature-box-icon">
</div>
</li>
<li>
<div class="feature-box-info">
<div class="feature-box-info">
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/massim.jpg" alt="author" />
</div>
<!--<h5>Massimo CRISTOFANILLI</h5>-->
Pr. Massimo CRISTOFANILLI, MD<br>
Medical Oncology<br>
Robert H. Lurie Comprehensive Cancer Center of Northwestern University. Chicago,
IL. USA<br>
IBC International Consortium President

<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
</div>
</div>
</div><br>
<div class="feature-box-icon">
</div>
</li>
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/marwa.jpg" alt="author" />
</div>
<!--<h5>Marwa MANAI </h5>-->
Dr.Marwa MANAI, PhD<br>
Molecular Oncology and Biomarkers<br>
Human Genetic Laboratory <br>
University of Tunis El Manar, Tunis, Tunisia
<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
</div>

</ul>
</div>
</div>
<div class="col-lg-4">
<div class="single-feature-box text-center">
<img src="assets/img/feature1.png" alt="feature">
</div><br><br><br>
<div class="col-lg-12">
<div class="single-feature-box text-lg- text-center">
<div class="author-img">
<img src="assets/img/author/franco.jpg" alt="author" /></center>
</div><br>

Pr. François BERTUCCI, MD<br>
Medical Oncology<br>
Department of Medical Oncology<br>
Paoli-Calmettes Institute, Marseille, France<br>

<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
<div class="author-img">
<img src="assets/img/author/houda.jpg" alt="author" /></center>
</div>
Dr. Houda EL BENNA, MD<br>
Oncology Center, Abderrahmen Mami Hospital, Ariana, Tunisia<br>
STOM member <br>
<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i><br><br><br>
</div>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="single-feature-box text-lg-left text-center">
<ul>
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/author4.png" alt="author" />
</div>
<!--<h5>Lotfi KOCHBATI </h5>-->
Pr. Lotfi KOCHBATI, MD<br>
Radiation Therapy<br>
Oncology Center, Abderrahmen Mami Hospital, Ariana, Tunisia<br>
<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i><br><br><br>
</div>
</div>
<li><br><br><br>
<br>
<br><br>
<br><br>
<div class="feature-box-icon">
</div>

<div class="feature-box-info">
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/khaledd.jpg" alt="author" />
</div>
<!--<h5>Khaled RAHAL</h5>-->  
Pr. Khaled RAHAL, MD<br>
Surgical Oncology<br>
Surgical Service, Salah Azaiez Institute, Tunis, Tunisia<br>

<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
</div>
</div>

</li><br><br>

<div class="col-lg-24">
<div class="single-testimonial-box">
<div class="author-img">
<img src="assets/img/author/nessrine.jpg" alt="author" />
</div>
<!--<h5>Nesrine MEJRI </h5>-->
Dr. Nesrine MEJRI, MD<br>
Medical Oncology<br>
Oncology Center, Abderrahmen Mami Hospital, Ariana, Tunisia<br>
<div class="author-rating">
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
<i class="icofont icofont-star"></i>
</div>
</div>
</ul>
</div>
</div>
</div>
</div>
</div><br><br><br><br>
<h6><b><center>Toward a better IBC patients care</center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress 
</b></h6>
<img src="assets/img/icone.png" alt="feature"> 

</div>
<section class="blog-area ptb-90" id="call">
<div class="container"><div class="row">
<div class="col-lg-12">
<div class="sec-title">
<h2>Submit Your Abstract<span class="sec-title-border"><span></span><span></span><span></span></span></h2><br>
<b><h4>Deadline July 15th, 2019.</h4></b>
</div>
<br>
<b><h3>Deadline July 15th, 2019.</h3></b>
<br>
</div>
</div>
<div class="row">
<div class="col-lg-6 col-md-4">
<div class="contact-form">
<p class="form-message"></p>    

<a href="http://ibc-workshop.com/assets/img/Abstract instructions.pdf"><h4><b>Click here to download the Instructions</b></h4></a>
</div>

</div>
<div class="col-lg-6 col-md-4">
<div class="contact-form">
<a href="submit.php"><h4><b>Click here to Submit Your Abstract</b></h4></a>

</form>
</div>
</div>

</div>
</div>
</section>
<section class="blog-area ptb-90" id="blog">
<div class="container"><div class="row">
<div class="col-lg-12">
<div class="sec-title">
<h2>Registration<span class="sec-title-border"><span></span><span></span><span></span></span></h2><br>
<p>......</p>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-6 col-md-4">
<div class="contact-form">
<p class="form-message"></p>    
<form id="contact-form" action="" method="POST">
<input type="text" name="name" placeholder="Name">
<input type="text" name="firstname" placeholder="First Name">
<input type="email" name="email" placeholder="E-MAIL">
<input type="text" name="country" placeholder="Country">
</div>
</div>
<div class="col-lg-6 col-md-4">
<div class="contact-form">

<p class="form-message"></p>
<input type="text" name="affiliation" placeholder="Affiliation">
<P>Grade<SELECT name="grade">
    <OPTION>PhD 
	<OPTION>Dr.
    <OPTION>Pr.
    <OPTION>Pr. MD.
</SELECT>
<label>Speciality    
<select name="speciality">
      <option value="Epidemiology">Epidemiology</option>
      <option value="Molecular biology">Molecular biology</option>
      <option value="Immunology">Immunology</option>
       <option value="Oncology">Oncology</option>
      <option value="Surgery">Surgery</option>
      <option value="Radiotherapy">Radiotherapy</option>
	   <option value="Other">Other</option>
  </select>
</label><br><br>
<button type="submit" name="submit">SEND</button><br><br><br>
</form>
<?php

			if(isset($_POST['submit'])){
						$host = "ibcworkspp2019.mysql.db";
						$user = "ibcworkspp2019";
						$password = "IBCworkspp2019";
						$dbname = "ibcworkspp2019";

				// Create connection
					$con = mysqli_connect($host, $user, $password,$dbname);
				
					
					$Nom = $_POST['name'];   
					$PreNom = $_POST['firstname'];   
					$Email = $_POST['email'];   
					$Pays = $_POST['country'];
					$Affiliation = $_POST['affiliation'];
					$Grade=$_POST['grade'];
					$Speciality=$_POST['speciality'];
					//$sql = "INSERT INTO invite (nom, prenom, email) VALUES ('Peter', 'Parker', 'peterparker@mail.com')";
					//echo ' \n Salut '. $Nom .' '. $Affiliation.' '.$PreNom .' '.$Email .' '.$Pays .' '. $Grade .' '. $Speciality.' <br/>Bienvenue sur mon site !';
					if (!mysqli_select_db($con,'ibcworkspp2019'))     
						die("Unable to select database: " . mysql_error()); 
					$sql_stmt = "INSERT INTO `invite` (`nom`,`prenom`,`email`,`pays`,`affiliation`,`grade`,`specialite`)"; 
					$sql_stmt .= " VALUES('$Nom','$PreNom','$Email', '$Pays', '$Affiliation','$Grade', '$Speciality')";   
					$result = mysqli_query($con,$sql_stmt);
					//echo "Entered data successfully\n";
					if ($result){
					echo '<script language="javascript">';
					echo 'alert("Entered data successfully")';
					echo '</script>';
					}
					if (!$result){
						die("Database access failed: " . mysqli_error()); 
					}
					
					
					 $to      = 'internationa.ibc.symposium@gmail.com';
					 $subject = 'New Registration';
					 $headers = "Content-Type: text/html; charset=\"iso-8859-1\"";
					 $headers .= "From: ".$Email . "\r\n" .
					 'Reply-To:internationa.ibc.symposium@gmail.com ' . "\r\n";
					 $message = '<html><body>';
						
						
						$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
						$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . strip_tags($Nom) . "</td></tr>";
						$message .= "<tr style='background: #eee;'><td><strong>firstname:</strong> </td><td>" . strip_tags($PreNom) . "</td></tr>";
						$message .= "<tr><td><strong>Email:</strong> </td><td>" . strip_tags($Email) . "</td></tr>";
						$message .= "<tr><td><strong>Pays:</strong> </td><td>" . strip_tags($Pays ) . "</td></tr>";
						$message .= "<tr><td><strong>Affiliation:</strong> </td><td>" . strip_tags($Affiliation) . "</td></tr>";
						$message .= "<tr><td><strong>Grade:</strong> </td><td>" . strip_tags($Grade) . "</td></tr>";
						$message .= "<tr><td><strong>Speciality:</strong> </td><td>" . strip_tags($Speciality) . "</td></tr>";
						//$message .= "<tr><td><strong>URL To Change (main):</strong> </td><td>" . $_POST['URL-main'] . "</td></tr>";
						//$addURLS = $_POST['addURLS'];
						
						$message .= "</table>";
						$message .= "</body></html>";
					 
						//print($message."\n");
						//print($headers
					 mail($to, $subject, $message, $headers);
					 
					 
					 // send to regist members
					 
					  $toR      = $Email;
					 $subjectR = 'Registration Confirmation';
					 $headersR = "Content-Type: text/html; charset=\"iso-8859-1\"";
					 $headersR .= "From: internationa.ibc.symposium@gmail.com \r\n" ;
					//'Reply-To:internationa.ibc.symposium@gmail.com ' . "\r\n";
					 $messageR = '<html><body>';
						
						
						$messageR .= "Dear, <br><br>" ;
						$messageR .= "Thank you for registering to the <b>\"1st International Workshop on Inflammatory Breast Cancer \".</b> <br><br>";
						$messageR .= "<b>Registration</b> <br>";
						$messageR .= "Confirmed registration and payment will be <b>on site at the registration desk at the Congress venue.</b>
                        We invite you to visit the meeting website (http://ibc-workshop.com/) in order to: <br><br>";
						$messageR .= "	Read the welcome message by the Organizing Committee <br>";
						$messageR .= "	Check the detailed meeting program <br>" ;
						$messageR .= "	Check the <b>payment fees</b> <br><br>";
						$messageR .= "It is our great pleasure to announce you that the abstract submission to the 1st International <b>Workshop on Inflammatory Breast Cancer</b> is now open. Abstracts must be submitted electronically only and the deadline for abstract submission is 15 July, 2019. <br><br>";
						$message .= "Please submit your abstract using the online abstract submission form:<br> http://ibc-workshop.com/submit.php <br><br>";
						$messageR .= "The following web page is regularly updated with exhibitors and sponsors.<br>All elected abstracts will be published in the abstract book, provided that the presenting author is registered to the Meeting.<br><br>";
						$messageR .= "The “1st International Workshop on IBC, 2019 in Tunis aims to bring together students, basic science researchers, clinicians and practitioners, as well as professionals from the health industry, in a forum to exchange and discuss current ideas, concepts and discoveries on IBC. <br><br>";
						$messageR .= "We kindly ask you to diffuse information about the event to anyone who may be interested.<br> 
Should you require any further information or assistance, please contact the administrative secretariat: internationa.ibc.symposium@gmail.com<br><br>

We are looking forward to welcoming you to Tunis in 25th-26th September, 2019.<br><br>

Sincerely,<br>
The Inflammatory Breast Cancer International Consortium,<br>
1st International Workshop on IBC organizers <br>";
						
						$messageR .= "<img src=\"http://ibc-workshop.com/assets/img/screenshot/ibc.jpg \" />" ; 
						$messageR .= "<img src=\"http://ibc-workshop.com/assets/img/logo1.jpg \"/>";
						$messageR .= "</body></html>";
					 
						//print($message."\n");
						//print($headers
					 mail($toR, $subjectR, $messageR, $headersR);
					
				}
				
        ?>
</div>
</div>
</div>
</div><br><br><br><br>
<h6><b><center>Toward a better IBC patients care </center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress
</b></h6>
<img src="assets/img/icone.png" alt="feature"> 

</div>
</section>
<section class="feature-area ptb-90" id="feature1">
<div class="row flexbox-center">
<div class="col-lg-4">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
<i class="icofont icofont-eye"></i>
</div>
<div class="feature-box-info">
<h4><center>Payements</center></h4><br>
Registration will be online and payement will be onsite at the registration desk of the congress venue. The registration fees for all registration types entitles delegates to the following: <br>
 Opening Reception (Wednesday 25 September)<br><br>
<p> All sessions, lunches and coffee breaks (from Wednesday 25 to Thursday 26 September)</p> <br>
<p> Admittance to exhibition</p> <br>
<p> Access to an electronic pdf listing of abstracts book</p> <br>
<p> Certificate of Attendance </p>
</div>
<div class="feature-box-icon">
</div>
</li>
</ul>
</div>
</div>
<div class="col-lg-4">
<div class="single-feature-box text-center">
<table border="5" style="line-hight:500px; width:105%;font-family:sans-serif;border: medium solid #000000;background-color: #FFFFFF;height:350px;">
   <tr>
      <th><center><h6><b>Participant</b></h6><center</th>
      <th><center><h6><b>Fees</b></h6></center></th>
      
   </tr>
   <tr>
      <td><h6><b>STOM members</b></h6></td>
      <td><h6><b>Membership+80 dinars</b></h6></td>
      
   </tr>
   <tr>
      <td><h6><b>STOR members</b></h6></td>
      <td><h6><b>Membership+80 dinars</b></h6></td>
      
   </tr>
   <tr>
      <td><h6><b>Residents, PhD Students</b></h6></td>
      <td><h6><b>40 dinars</b></h6></td>
      
   </tr>
<tr>
      <td><h6><b>Medical Doctor</b></h6></td>
      <td><h6><b>120 dinars</b></h6></td>
      
   </tr>
 <tr>
      <td><h6><b>Scientists</b></h6></td>
      <td><h6><b>120 dinars</b></h6></td>
      
   </tr>
  
 <tr>
      <td><h6><b>Pharmacists</b></h6></td>
      <td><h6><b>120 dinars</b></h6></td>
      
   </tr>
 <tr>
      <td><h6><b>Other healthcare Professionals</b></h6></td>
      <td><h6><b>120 dinars</b></h6></td>
      
   </tr>
   <tr>
      <td><h6><b>Patient advocate</b></h6></td>
      <td><h6><b>Free</b></h6></td>    
      
   </tr>
<tr>
      <td><h6><b>Press</b></h6></td>
      <td><h6><b>Free</b></h6></td>    
   </tr>
   </table><br><br><br>
  </div>
</div>
<div class="col-lg-3">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
<div class="feature-box-icon">
<i class="icofont icofont-eye"></i>
</div>
</div>
<div class="feature-box-info">       
<h4><center>Confirmation</center></h4><br>
<p>Your online registration will be automatically acknowledged via email with confirmation of your requirements according to your registration form </p><br>
<h4><center>Invitation Letter </center></h4><br>
<p>The congress organization will be pleased to send a formal letter of invitation to delegates requesting an invitation letter. The letters will be sent as e-mail attachments once the registration has been done. </p><br>
</div>
</li>
</ul>
</div>
</div>
</div>
</div><br><br><br><br><br><br><br><br><br>
<h6><b><center>Toward a better IBC patients care </center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress
</b></h6>
<img src="assets/img/icone.png" alt="feature"> 
</div>
</section>
</section>
<footer class="footer" id="contact">
<div class="container">
<div class="row">
<div class="col-lg-6">
<div class="contact-form">
<h4>Contact US</h4>
<p class="form-message"></p>
<form id="contact-form" action="#" method="POST">
<input type="text" name="name" placeholder="Name">
<input type="email" name="email" placeholder=" Email">
<textarea placeholder="Messege" name="message"></textarea>
<button type="submit" name="send">Send Message</button>
<br><br>
</form>
<?php

			if(isset($_POST['send'])){
						$host = "ibcworkspp2019.mysql.db";
						$user = "ibcworkspp2019";
						$password = "IBCworkspp2019";
						$dbname = "ibcworkspp2019";

				// Create connection
					$con = mysqli_connect($host, $user, $password,$dbname);
				
			   
					$Name = $_POST['name'];   
					$Email = $_POST['email'];   					
					$Message=$_POST['message'];
					
					
					//$sql = "INSERT INTO invite (nom, prenom, email) VALUES ('Peter', 'Parker', 'peterparker@mail.com')";
					//echo ' \n Salut '. $Nom .' '. $Affiliation.' '.$PreNom .' '.$Email .' '.$Pays .' '. $Grade .' '. $Speciality.' <br/>Bienvenue sur mon site !';
					if (!mysqli_select_db($con,'ibcworkspp2019'))     
						die("Unable to select database: " . mysql_error()); 
					$sql_stmt = "INSERT INTO `contact` (`name`,`email`,`message`)"; 
					$sql_stmt .= " VALUES('$Name','$Email','$Message')";   
					$result = mysqli_query($con,$sql_stmt);
					//echo "Entered data successfully\n";
					if ($result){
					echo '<script language="javascript">';
					echo 'alert("Entered data successfully")';
					echo '</script>';
					}
					if (!$result){
						die("Database access failed: " . mysqli_error()); 
					}
					// send mail
					$to      ='internationa.ibc.symposium@gmail.com';
					 $subject = 'Contact US';
					 $headers = "Content-Type: text/html; charset=\"iso-8859-1\"";
					 $headers .= "From: ".$Email . "\r\n" .
					 'Reply-To: internationa.ibc.symposium@gmail.com' . "\r\n" .
					 'X-Mailer: PHP/' . phpversion();
					 $message = '<html><body>';
						
						
						$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
						$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . strip_tags($Name) . "</td></tr>";
						//$message .= "<tr style='background: #eee;'><td><strong>Name:</strong> </td><td>" . strip_tags($Prenom) . "</td></tr>";
						$message .= "<tr><td><strong>Email:</strong> </td><td>" . strip_tags($Email) . "</td></tr>";
						$message .= "<tr><td><strong>Message:</strong> </td><td>" . strip_tags($Message) . "</td></tr>";
						//$message .= "<tr><td><strong>Affiliation:</strong> </td><td>" . strip_tags($Pays ) . "</td></tr>";
						//$message .= "<tr><td><strong>Urgency:</strong> </td><td>" . strip_tags($Affiliation) . "</td></tr>";
						//$message .= "<tr><td><strong>Urgency:</strong> </td><td>" . strip_tags($Grade) . "</td></tr>";
						//$message .= "<tr><td><strong>URL To Change (main):</strong> </td><td>" . $_POST['URL-main'] . "</td></tr>";
						//$addURLS = $_POST['addURLS'];
						
						$message .= "</table>";
						$message .= "</body></html>";
					 
						//print($message."\n");
						//print($headers
					 mail($to, $subject, $message, $headers);
					
					
					
					
				}
				
        ?>
</div>
</div>
<div class="col-lg-6">
<div class="contact-address">
<h4>Address</h4>
<p> Boulevard Principal 1053 Les Berges du Lac, Tunis, Tunisia</p>
<ul>
<li>
<div class="contact-address-icon">
<i class="icofont icofont-headphone-alt"></i>

</div>
<div class="contact-address-info">
<a href="callto:#"><b>Bouthaina Kanzari</b>&nbsp &nbsp00216 29 902 626<div class="author-img"><img src="assets/img/bouth.png" width="80" height="70"></a></div>
</div>
</li>
<li>
<div class="contact-address-icon">
<i class="icofont icofont-envelope"></i>
</div>
<div class="contact-address-info">
<!--<a href="https://colorlib.com/cdn-cgi/l/email-protection#f9da">-->
internationa.ibc.symposium@gmail.com</a><br><br>
</div>
</li>

</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-lg-12">
<div class="subscribe-form">
</div>
</div>
</div>

</div>
</footer>
<section class="feature-area11 ptb-90" id="call">
<div class="container">
<div class="row flexbox-left">
<div class="col-lg-30">


</a>

<script src="assets/js/jquery.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/jquery.slicknav.min.js"></script>

<script src="assets/js/slick.min.js"></script>

<script src="assets/js/owl.carousel.min.js"></script>

<script src="assets/js/jquery.magnific-popup.min.js"></script>

<script src="assets/js/jquery.counterup.min.js"></script>

<script src="assets/js/waypoints.min.js"></script>

<script src="assets/js/jquery.mb.YTPlayer.min.js"></script>

<script src="assets/js/jquery.easing.1.3.html"></script>

<script src="assets/js/gmap3.min.js"></script>


<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25551.597769610733!2d10.193228510197931!3d36.81972472159004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd351581c9df5d%3A0x8e8081c464d3bae1!2sARENA!5e0!3m2!1sfr!2stn!4v1556022411517!5m2!1sfr!2stn" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
<div class="row">
<div class="col-lg-12">

</div>
</div>
<section class="feature1-area ptb-90" id="feature">
<div class="row flexbox-center">
<div class="col-lg-4">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
<i class="icofont icofont-eye"></i>
</div>
<div class="feature-box-info">
<h6><b>&nbsp &nbsp &nbsp &nbsp &nbsp Accommodation</b></h6><br><br>
<h6>Accomodation hotels close to the venue are:<br><br>
•	Concorde Hotel Les Berges du Lac:<br><br><a href="http://www.concorde-tunisia.com/En/"><h6><b>http://www.concorde-tunisia.com/En</b></h6></a><br>
•	Mövenpick Hotel Du Lac Tunis :<br><br> <a href="https://www.movenpick.com/en/africa/tunisia/"><h6><b>https://www.movenpick.com/en/africa/tunisia/</b></h6></a><br>
• Hotel Acropole:<br><br><a href="http://www.acropole.tn/en/"><h6><b>http://www.acropole.tn/en/</b></h6></a><br>
<p>	<h6>• Hotel Paris:<h6></p><br><a href="http://www.concorde-tunisia.com/Fr/hotel-paris-contacts_10_37"><h6><b>http://www.concorde-tunisia.com/Fr/hotel-paris-contacts_10_37</b></h6></a><br>
</div>
</li>
</ul>
</div>
</div>

<div class="col-lg-8">
<div class="single-feature-box text-lg-left text-center">
<ul>
<li>
<div class="feature-box-icon">
</div>
<div class="feature-box-info">      

<img src="assets/img/event.jpg" alt="Hand Mockup" />
</div>
</li>
</ul>
</div>
</div>
</div>
</section>
<p><b><h4>Visa needed for:</b> Afghanistan, Afrique du Sud, Albanie, Angola, Argentine, Australie, Bangladesh, Bénin, Brésil, Bulgarie, Burkina Faso,<br><br> Burundi, Cameroun, Cap-Vert, Chine, Chypre, Colombie, Congo, Costa Rica, Cuba, Djibouti, Egypte, Equateur, Ethiopie, Gabon, Guinée-<br><br>Bissau, Guinée Equatoriale, Hongrie, Inde, Indonésie, Iran, Iraq, Jordanie, Kenya, Lesotho, Liban, Madagascar, Mexique, Mongolie, Népal,<br><br> Nigeria, Nouvelle-Zélande, Pakistan, Panama, Paraguay, Pérou, Philippines, Pologne, République Arabe Syrienne, République Centrafricaine,<br><br> République de Corée (pour une période excédant trente jours), République-Unie de Tanzanie, Rwanda, Sao Tomé-et-Principe, Sierra Leone,<br><br> Singapour, Somalie, Soudan, Sri Lanka, Tchad, Thaïlande, Togo, Uruguay, Vénézuela, Vietnam, Yémen, Zaïre, Zambie, Zimbabwe, 
the<br><br> countries of the Commonwealth of Independent States. </h4></p>
</li>
<section class="screenshots-area ptb-90" id="screenshot">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="sec-title">
<h2>#<b>Visit</b> #<b>Tunisia</b><span class="sec-title-border"><span></span><span></span><span></span></span></h2>
<p> </p>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-12">
<div class="screenshot-wrap">
<div class="single-screenshot">
<img src="assets/img/eljam.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/sidi.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/hero-area2.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/tunis.jpg" alt="screenshot" />
</div>
<div class="single-screenshot">
<img src="assets/img/cc.jpg" alt="screenshot" />
</div>



</div>
<h6><b><center>Toward a better IBC patients care </center></b></h6><br>
<div class="single-feature-box text-center"> 
<h6><b>This is a paper free congress
</b></h6>
<img src="assets/img/icone.png" alt="feature"> 

</div>
</div>
</div>
</div>
</div>
</section>

<script src="assets/js/custom-map.js"></script>  

<script src="assets/js/wow-1.3.0.min.js"></script>

<script src="assets/js/switcher.js"></script>

<script src="assets/js/main.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</div>
</div>
</div>
</div>
</section>

<footer class="footer" id="contact">
<div class="container">


<div class="row">
<div class="col-lg-12">
<div class="copyright-area">
<!--<ul>
<li><a href="#"><i class="icofont icofont-social-facebook"></i></a></li>
<li><a href="#"><i class="icofont icofont-social-twitter"></i></a></li>
<li><a href="#"><i class="icofont icofont-brand-linkedin"></i></a></li>
<li><a href="#"><i class="icofont icofont-social-pinterest"></i></a></li>
<li><a href="#"><i class="icofont icofont-social-google-plus"></i></a></li></center>
</ul>-->
<p>&copy; Copyright &copy;<script data-cfasync="false" src="../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | This Site is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://www.linkedin.com/in/mohamed-mars-4b894b150" target="_blank">Mars Mohamed</a>
</p>
</div>
</div>
</div>
</div>
</div>
</footer>
</body>
</html>